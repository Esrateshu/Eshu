# Simple Calculator Using Flex and Bison

Evaluating a complex arithmetic expression consisting of the basic arithmetic operations using flex and bison - the open-source version of lex and yacc respectively.
